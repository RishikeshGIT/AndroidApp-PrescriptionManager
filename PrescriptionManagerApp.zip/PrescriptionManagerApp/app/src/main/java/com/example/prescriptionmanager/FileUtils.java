package com.example.prescriptionmanager;

public class FileUtils {
    //method to read data from the text file



    //method to store data in the text file
    //given a line transform it into the format of data
}
