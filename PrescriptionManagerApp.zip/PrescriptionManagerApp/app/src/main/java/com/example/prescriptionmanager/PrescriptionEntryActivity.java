package com.example.prescriptionmanager;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PrescriptionEntryActivity extends AppCompatActivity {
    EditText editText_PatientId, editText_Prescription_Data, editText_Observation_Data;
    Button edit_editButton, edit_saveButton, edit_goButton;
    TextView edit_doctor_name;
    public static final String TAG = "TAG";
    String editText_PatientId_Value = null;
    FirebaseFirestore firebaseFirestoreDb = FirebaseFirestore.getInstance();
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_entry);

        editText_PatientId = (EditText) findViewById(R.id.PE_PatientId);
        editText_Prescription_Data = (EditText) findViewById(R.id.PE_PrescriptionData);
        editText_Observation_Data = (EditText) findViewById(R.id.PE_ObservationData);
        edit_editButton = (Button) findViewById(R.id.PE_editBtn);
        edit_saveButton = (Button) findViewById(R.id.PE_SaveBtn);
        edit_goButton = (Button) findViewById(R.id.PE_GoBtn);
        edit_doctor_name = (TextView) findViewById(R.id.PE_DoctorName);

        editText_Prescription_Data.setEnabled(false);
        editText_Observation_Data.setEnabled(false);

        edit_editButton.setOnClickListener((v) -> {
            editText_Prescription_Data.setEnabled(true);
            editText_Observation_Data.setEnabled(true);
        });

        edit_goButton.setOnClickListener((v) -> {
            readPrescriptionDataFromDBAndDisplayOnUI((EditText) findViewById(R.id.PE_PatientId), (EditText) findViewById(R.id.PE_PrescriptionData),
                    (EditText) findViewById(R.id.PE_ObservationData), (TextView) findViewById(R.id.PE_DoctorName));
        });
        edit_saveButton.setOnClickListener((v) -> {
            getPrescriptionDataAndSaveInDatabase(editText_Prescription_Data.getText().toString().trim(), editText_Observation_Data.getText().toString().trim());
        });
    }

    /*      This is how we get the Prescription data from the EditText field. This needs to be parsed properly and then saved in the FireStore DB.
                   Prescriptions:
                   1.	Tab1:1+1+1:7days
                   2.	Tab2:0+1+0:7days
                   3.	Tab3:1+0+1:7days
                   GeneralObservation=> Mild cough. Nothing to worry. Take medicines and return after 7 days.
        */
    public void getPrescriptionDataAndSaveInDatabase(String prescription_data_text, String observation_data_text) {
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.PE_ProgressBar);
        progressBar.setVisibility(View.VISIBLE);

        String [] prescription_array_0 = prescription_data_text.split("\n");
        String prescription_item_1 = prescription_array_0[1].split("1\\.\t")[1];
        String prescription_item_2 = prescription_array_0[2].split("2\\.\t")[1];
        String prescription_item_3 = prescription_array_0[3].split("3\\.\t")[1];

        //save data in Firebase FireStore database
        savePrescriptionDataInFireStore(editText_PatientId_Value, edit_doctor_name.getText().toString().trim(), prescription_item_1, prescription_item_2, prescription_item_3, observation_data_text);
        progressBar.setVisibility(View.GONE);
        Toast.makeText(PrescriptionEntryActivity.this, "Prescription Data saved successfully", Toast.LENGTH_SHORT).show();
    }

    public void readPrescriptionDataFromDBAndDisplayOnUI(EditText editText_PatientId, EditText editText_Prescription_Data, EditText editText_Observation_Data, TextView edit_doctor_name) {
        editText_PatientId_Value = editText_PatientId.getText().toString().trim();
        if (TextUtils.isEmpty(editText_PatientId_Value)) {
            editText_PatientId.setError("Patient Id is null");
            return;
        }

        //Extract the Doctor's name from Database
        String doctorId = firebaseAuth.getCurrentUser().getUid();
        documentReference = firebaseFirestoreDb.collection("doctors").document(doctorId);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                edit_doctor_name.setText("Doctor's Name: " + documentSnapshot.getString("doctorName"));
            }
        });

        //extract the details of the Patient from the FireStore DB
        documentReference = firebaseFirestoreDb.collection("prescriptions").document(editText_PatientId_Value);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){
                        String tab1_details = new StringBuffer("1.\t").append(documentSnapshot.getString("tab1_name"))
                                .append("\t:\t").append(documentSnapshot.getString("tab1_timing"))
                                .append("\t:\t").append(documentSnapshot.getString("tab1_days")).toString();
                        String tab2_details = new StringBuffer("2.\t").append(documentSnapshot.getString("tab2_name"))
                                .append("\t:\t").append(documentSnapshot.getString("tab2_timing"))
                                .append("\t:\t").append(documentSnapshot.getString("tab2_days")).toString();
                        String tab3_details = new StringBuffer("3.\t").append(documentSnapshot.getString("tab3_name"))
                                .append("\t:\t").append(documentSnapshot.getString("tab3_timing"))
                                .append("\t:\t").append(documentSnapshot.getString("tab3_days")).toString();
                        String Observation = new StringBuffer("General Observation:\n").append(documentSnapshot.getString("GeneralObservation")).toString();
                        editText_Prescription_Data.setText(new StringBuffer("Prescriptions:\n").append(tab1_details).append("\n").append(tab2_details).append("\n").append(tab3_details).toString());
                        editText_Observation_Data.setText(Observation);
                    } else {
                        editText_Prescription_Data.setText(new StringBuffer("Prescriptions:\n").append("No Prescription Available").toString());
                        editText_Observation_Data.setText(new StringBuffer("General Observation:\n").append("No Observation Available").toString());
                    }
                } else {
                    editText_Prescription_Data.setText(new StringBuffer("Prescriptions:\n").append("No Prescription Available").toString());
                    editText_Observation_Data.setText(new StringBuffer("General Observation:\n").append("No Observation Available").toString());
                }
            }
        });
    }

    public void savePrescriptionDataInFireStore(String patientId, String doctor_name, String prscriptionItem_1, String prscriptionItem_2, String prscriptionItem_3, String observation_data) {
        //Prescription data format: Tab1:1+1+1:7days
        //Observation data format: anyString
        String[] tabs_array;
        Map<String, Object> patient = new HashMap<>();
        patient.put("patientId", patientId);
        patient.put("doctorName", doctor_name.split(":")[1].trim());

        tabs_array = prscriptionItem_1.split(":");
        patient.put("tab1_name", tabs_array[0]);
        patient.put("tab1_timing", tabs_array[1]);
        patient.put("tab1_days", tabs_array[2]);

        tabs_array = prscriptionItem_2.split(":");
        patient.put("tab2_name", tabs_array[0]);
        patient.put("tab2_timing", tabs_array[1]);
        patient.put("tab2_days", tabs_array[2]);

        tabs_array = prscriptionItem_3.split(":");
        patient.put("tab3_name", tabs_array[0]);
        patient.put("tab3_timing", tabs_array[1]);
        patient.put("tab3_days", tabs_array[2]);

        patient.put("GeneralObservation", observation_data);

        // Add a new document with a generated ID
        firebaseFirestoreDb.collection("prescriptions")
                .document(patientId)
                .set(patient)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Prescription data added for the Patient: " + patientId);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Error while saving Prescription data for patient: " + patientId);
                    }
                });
    }

    public void savePatientPrescriptionAndObservationDataInFile(String prescription_data_to_save) {
        File path = getApplicationContext().getFilesDir();
        System.out.println("Path:"+ path.getAbsolutePath());
        try(OutputStreamWriter outputStreamWriter = new OutputStreamWriter(getApplicationContext().openFileOutput("subscription_list.txt", Context.MODE_PRIVATE))) {
            outputStreamWriter.write(prescription_data_to_save);
            outputStreamWriter.write("\n");
        } catch (IOException ioe) {
            System.out.println("Exception while writing data to file: "+ioe.getMessage());
            ioe.printStackTrace();
        }
    }

    public List<String> readTextFile() {
        String line = "";
        List<String> linesList = new ArrayList<>();

        try(InputStream is = this.getResources().openRawResource(R.raw.subscription_list);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));) {
            while((line = reader.readLine()) != null)
                linesList.add(line);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return linesList;
    }
}
