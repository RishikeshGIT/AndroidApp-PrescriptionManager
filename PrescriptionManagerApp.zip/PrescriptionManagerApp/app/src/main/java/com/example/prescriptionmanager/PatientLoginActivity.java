package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class PatientLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        final Button goButton = (Button) findViewById(R.id.PatientGoBtn);
        final EditText editTextPatientId = (EditText) findViewById(R.id.PatientId);
        goButton.setOnClickListener((v) -> {
            Intent prescriptionViewIntent = new Intent(PatientLoginActivity.this, PrescriptionViewActivity.class);
            prescriptionViewIntent.putExtra("PATIENT_ID", editTextPatientId.getText().toString());
            PatientLoginActivity.this.startActivity(prescriptionViewIntent);
        });
    }
}
