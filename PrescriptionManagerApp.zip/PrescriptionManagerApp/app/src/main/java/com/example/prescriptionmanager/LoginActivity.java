package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    EditText login_email, login_password;
    Button login_login;
    ProgressBar login_progressBar;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_email = (EditText) findViewById(R.id.email);
        login_password = (EditText) findViewById(R.id.password);
        login_login = (Button) findViewById(R.id.Login);
        login_progressBar = (ProgressBar) findViewById(R.id.LoginPageProgressBar);
        firebaseAuth = FirebaseAuth.getInstance();

        final TextView login_registerLink = (TextView) findViewById(R.id.RegisterLink);
        login_registerLink.setOnClickListener((v) -> {
            Intent registrationIntent = new Intent(LoginActivity.this, RegistrationActivity.class);
            LoginActivity.this.startActivity(registrationIntent);
        });

        Button login_logout_btn = (Button) findViewById(R.id.login_Logout);
        Bundle bundle = getIntent().getExtras();
        String loggedInStatus = bundle != null ? bundle.getString("DOCTOR_LOGIN_STATE") : "No status of Doctor's Logged-in.";
        if(loggedInStatus.equalsIgnoreCase("loggedIn"))
            login_logout_btn.setVisibility(View.VISIBLE);

        login_logout_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                finish();
            }
        });

        login_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = login_email.getText().toString().trim();
                String password = login_password.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    login_email.setError("Email is Required.");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    login_email.setError("Password is Required.");
                    return;
                }
                if(password.length() < 6){
                    login_password.setError("Password can not be less than 6 characters.");
                    return;
                }

                login_progressBar.setVisibility(View.VISIBLE);
                //Authenticate the User
                firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(LoginActivity.this, "Logged-In successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), PrescriptionEntryActivity.class));
                        } else {
                            Toast.makeText(LoginActivity.this, "Login Failed."+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            login_progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });
    }
}
