package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SetAlarmActivity extends AppCompatActivity {
    public static final String TAG = "TAG";
    EditText editText;
    RadioButton radioButton_m, radioButton_a, radioButton_e;
    ToggleButton toggleButton;
    TextView hiddenTextViewAsPlaceholder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);
        Bundle bundle = getIntent().getExtras();
        String patientId = bundle != null ? bundle.getString("PATIENT_ID") : "Pat002";

        getPatientPrescriptionDataFromFireStoreDB(patientId);

        Button setAlarmSubmitBtn = (Button) findViewById(R.id.SetAlarmSubmitBtn);
        setAlarmSubmitBtn.setOnClickListener((v) -> {
            Intent alarmSettingConfirmationIntent = new Intent(SetAlarmActivity.this, SubmitAlarmConfirmationActivity.class);
            SetAlarmActivity.this.startActivity(alarmSettingConfirmationIntent);
        });
    }

    private void getPatientPrescriptionDataFromFireStoreDB(String patientId) {
        Map<String, String> prescriptionDataMap = new HashMap<>();
        FirebaseFirestore firebaseFirestoreDb = FirebaseFirestore.getInstance();
        DocumentReference documentReference = firebaseFirestoreDb.collection("prescriptions").document(patientId);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()) {
                        prescriptionDataMap.put("tab1_name", documentSnapshot.getString("tab1_name").trim());
                        prescriptionDataMap.put("tab1_timing", documentSnapshot.getString("tab1_timing").trim());
                        prescriptionDataMap.put("tab1_days", documentSnapshot.getString("tab1_days").trim());

                        prescriptionDataMap.put("tab2_name", documentSnapshot.getString("tab2_name").trim());
                        prescriptionDataMap.put("tab2_timing", documentSnapshot.getString("tab2_timing").trim());
                        prescriptionDataMap.put("tab2_days", documentSnapshot.getString("tab2_days").trim());

                        prescriptionDataMap.put("tab3_name", documentSnapshot.getString("tab3_name").trim());
                        prescriptionDataMap.put("tab3_timing", documentSnapshot.getString("tab3_timing").trim());
                        prescriptionDataMap.put("tab3_days", documentSnapshot.getString("tab3_days").trim());

                        prescriptionDataMap.put("GeneralObservation", documentSnapshot.getString("GeneralObservation").trim());
                        prescriptionDataMap.put("DoctorName", documentSnapshot.getString("doctorName").trim());

                        displayPrescriptionDataOnSetAlarmPage(prescriptionDataMap);
                    } else {
                        Log.d(TAG, "Can not read the Patient prescription data");
                    }
                } else {
                    Log.d(TAG, "Can not read the Patient prescription data");
                }
            }
        });
    }

    private void displayPrescriptionDataOnSetAlarmPage(Map<String, String> patientPrescriptionData) {
        EditText editText_4_tab1_name, editText_4_tab2_name, editText_4_tab3_name;
        RadioButton radioButton_4_tab1_R1, radioButton_4_tab1_R2, radioButton_4_tab1_R3, radioButton_4_tab2_R1, radioButton_4_tab2_R2, radioButton_4_tab2_R3,
                radioButton_4_tab3_R1, radioButton_4_tab3_R2, radioButton_4_tab3_R3;
        ToggleButton toggleButton_4_tab1, toggleButton_4_tab2, toggleButton_4_tab3;

        editText_4_tab1_name = (EditText) findViewById(R.id.setAlarmTab1Name);
        editText_4_tab2_name = (EditText) findViewById(R.id.setAlarmTab2Name);
        editText_4_tab3_name = (EditText) findViewById(R.id.setAlarmTab3Name);

        toggleButton_4_tab1 = (ToggleButton) findViewById(R.id.SetAlarmTab1TBtn);
        toggleButton_4_tab2 = (ToggleButton) findViewById(R.id.setAlarmTab2TBtn);
        toggleButton_4_tab3 = (ToggleButton) findViewById(R.id.setAlarmTab3TBtn);

        radioButton_4_tab1_R1 = (RadioButton) findViewById(R.id.setAlarmTab1Radio1);
        radioButton_4_tab1_R2 = (RadioButton) findViewById(R.id.setAlarmTab1Radio2);
        radioButton_4_tab1_R3 = (RadioButton) findViewById(R.id.setAlarmTab1Radio3);

        radioButton_4_tab2_R1 = (RadioButton) findViewById(R.id.setAlarmTab2Radio1);
        radioButton_4_tab2_R2 = (RadioButton) findViewById(R.id.setAlarmTab2Radio2);
        radioButton_4_tab2_R3 = (RadioButton) findViewById(R.id.setAlarmTab2Radio3);

        radioButton_4_tab3_R1 = (RadioButton) findViewById(R.id.setAlarmTab3Radio1);
        radioButton_4_tab3_R2 = (RadioButton) findViewById(R.id.setAlarmTab3Radio2);
        radioButton_4_tab3_R3 = (RadioButton) findViewById(R.id.setAlarmTab3Radio3);

        Set<String> keySet = patientPrescriptionData.keySet();
        for(String key : keySet) {
            String switchCaseText = key.split("_")[0].trim();
            switch (switchCaseText){
                case "tab1":
                    if("tab1_name".equals(key)){
                        editText_4_tab1_name.setText(patientPrescriptionData.get(key));
                        editText_4_tab1_name.setVisibility(View.VISIBLE);
                    } else if ("tab1_timing".equals(key)) {
                        setRadioButtonForTiming("tab1", patientPrescriptionData.get(key), radioButton_4_tab1_R1, radioButton_4_tab1_R2, radioButton_4_tab1_R3);
                        toggleButton_4_tab1.setVisibility(View.VISIBLE);
                    }
                    break;
                case "tab2":
                    if("tab2_name".equals(key)) {
                        editText_4_tab2_name.setText(patientPrescriptionData.get(key));
                        editText_4_tab2_name.setVisibility(View.VISIBLE);
                    }
                    else if ("tab2_timing".equals(key)) {
                        setRadioButtonForTiming("tab2", patientPrescriptionData.get(key), radioButton_4_tab2_R1, radioButton_4_tab2_R2, radioButton_4_tab2_R3);
                        toggleButton_4_tab2.setVisibility(View.VISIBLE);
                    }
                    break;
                case "tab3":
                    if("tab3_name".equals(key)) {
                        editText_4_tab3_name.setText(patientPrescriptionData.get(key));
                        editText_4_tab3_name.setVisibility(View.VISIBLE);
                    } else if ("tab3_timing".equals(key)) {
                        setRadioButtonForTiming("tab3", patientPrescriptionData.get(key), radioButton_4_tab3_R1, radioButton_4_tab3_R2, radioButton_4_tab3_R3);
                        toggleButton_4_tab3.setVisibility(View.VISIBLE);
                    }
                    break;
                default:
                    System.out.println("Default");
                    break;
            }
        }
    }

    private void setRadioButtonForTiming(String tabPrefix, String timingText, RadioButton rB_morning, RadioButton rB_noon, RadioButton rB_evening) {
        String[] timingArray = timingText.split("\\+");
        boolean mAlarm = Integer.parseInt(timingArray[0].trim()) > 0 ? true : false;
        boolean aAlarm = Integer.parseInt(timingArray[1].trim()) > 0 ? true : false;
        boolean eAlarm = Integer.parseInt(timingArray[2].trim()) > 0 ? true : false;
        rB_morning.setText("Morning");
        rB_morning.setVisibility(View.VISIBLE);
        rB_noon.setText("Afternoon");
        rB_noon.setVisibility(View.VISIBLE);
        rB_evening.setText("Evening");
        rB_evening.setVisibility(View.VISIBLE);
        if(mAlarm) {
            rB_morning.setChecked(true);
        } else {
            rB_morning.setChecked(false);
            rB_morning.setEnabled(false);
        }
        if(aAlarm) {
            rB_noon.setChecked(true);
        } else {
            rB_noon.setChecked(false);
            rB_noon.setEnabled(false);
        }
        if(eAlarm) {
            rB_evening.setChecked(true);
        } else {
            rB_evening.setChecked(false);
            rB_evening.setEnabled(false);
        }
    }
}
