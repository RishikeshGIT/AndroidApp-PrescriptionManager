package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_view);
        Bundle bundle = getIntent().getExtras();
        String PV_patientId = bundle.get("PATIENT_ID").toString().trim();
        TextView PatPrescriptionTextView = (TextView) findViewById(R.id.PatPrescriptionTextView);
        TextView observationTextView = (TextView) findViewById(R.id.PatObservationView);
        Button setAlarmBtn = (Button) findViewById(R.id.SetAlarm);

        setAlarmBtn.setClickable(false);

        setAlarmBtn.setOnClickListener((v) -> {
            Intent setAlarmIntent = new Intent(PrescriptionViewActivity.this, SetAlarmActivity.class);
            setAlarmIntent.putExtra("PRESCRIPTION_TEXT", PatPrescriptionTextView.getText().toString());
            setAlarmIntent.putExtra("PATIENT_ID", PV_patientId);
            PrescriptionViewActivity.this.startActivity(setAlarmIntent);
        });

        getPrescriptionDataFromFireStoreDB(PV_patientId, PatPrescriptionTextView, observationTextView);
    }

    public void getPrescriptionDataFromFireStoreDB(String pvPatientId, TextView PatPrescriptionTextView, TextView observationTextView) {
        ProgressBar progressBar = findViewById(R.id.progressBar); // Get ProgressBar reference
        ConstraintLayout mainContent = findViewById(R.id.mainContent);

        final String NO_PRESCRIPTION_MESSAGE = "No Prescription is available for this Patient";
        FirebaseFirestore firebaseFirestoreDb = FirebaseFirestore.getInstance();
        DocumentReference documentReference = firebaseFirestoreDb.collection("prescriptions").document(pvPatientId);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                progressBar.setVisibility(View.GONE); // Hide Progress bar
                mainContent.setVisibility(View.VISIBLE); // Show TextView
                if(task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){
                        String doctorName = documentSnapshot.getString("doctorName").trim();
                        String tab1_details = new StringBuffer("1.\t").append(documentSnapshot.getString("tab1_name"))
                                .append("\t:\t").append(transformTimingsDataInDeclarativeFormat(documentSnapshot.getString("tab1_timing").trim()))
                                .append("\t:\t").append(transformDurationDataInDeclarativeFormat(documentSnapshot.getString("tab1_days").trim()))
                                .toString();
                        String tab2_details = new StringBuffer("2.\t").append(documentSnapshot.getString("tab2_name"))
                                .append("\t:\t").append(transformTimingsDataInDeclarativeFormat(documentSnapshot.getString("tab2_timing").trim()))
                                .append("\t:\t").append(transformDurationDataInDeclarativeFormat(documentSnapshot.getString("tab2_days").trim()))
                                .toString();
                        String tab3_details = new StringBuffer("3.\t").append(documentSnapshot.getString("tab3_name"))
                                .append("\t:\t").append(transformTimingsDataInDeclarativeFormat(documentSnapshot.getString("tab3_timing").trim()))
                                .append("\t:\t").append(transformDurationDataInDeclarativeFormat(documentSnapshot.getString("tab3_days").trim()))
                                .toString();
                        String Observation = new StringBuffer("General Observation:\n").append(documentSnapshot.getString("GeneralObservation")).toString();

                        displayPrescriptionDataOnPrescriptionViewPage(doctorName, tab1_details, tab2_details, tab3_details, Observation, PatPrescriptionTextView, observationTextView);
                    } else {
                        displayErrorTextOnPrescriptionViewPage(NO_PRESCRIPTION_MESSAGE);
                    }
                } else {
                    displayErrorTextOnPrescriptionViewPage(NO_PRESCRIPTION_MESSAGE);
                }
            }
        });
    }

    private void displayErrorTextOnPrescriptionViewPage(String errorMessage) {
        TextView prescriptionField = (TextView) findViewById(R.id.PatPrescriptionTextView);
        TextView observationField = (TextView) findViewById(R.id.PatObservationView);
        prescriptionField.setText(errorMessage);
        observationField.setText(errorMessage);
        return;
    }

    private void displayPrescriptionDataOnPrescriptionViewPage(String doctorName, String tab1_details, String tab2_details, String tab3_details,
                                                               String observation, TextView PatPrescriptionTextView, TextView observationTextView) {
        TextView pvDoctorName = (TextView) findViewById(R.id.PV_doctorName);
        pvDoctorName.setText("Prescription By: "+doctorName);
        PatPrescriptionTextView.setText(new StringBuffer("Prescriptions:\n")
                .append(tab1_details).append("\n")
                .append(tab2_details).append("\n")
                .append(tab3_details)
                .toString());
        observationTextView.setText(observation);
    }

    private String transformTimingsDataInDeclarativeFormat(String timings) {
        //timings input format:=> 1+1+1
        return getTimeMessageInTextFormat(timings);
    }

    private String transformDurationDataInDeclarativeFormat(String duration) {
        //duration input format:=> 7days
        return new StringBuffer("Duation: For ").append(duration).toString();
    }

    private String getTimeMessageInTextFormat(String message) {
        String [] strings = message.split("\\+");
        StringBuffer stringBuffer = new StringBuffer("\tDosages: ");
        int count_0 = Integer.parseInt(strings[0].trim());
        int count_1 = Integer.parseInt(strings[1].trim());
        int count_2 = Integer.parseInt(strings[2].trim());
        if (count_0 > 0)
            stringBuffer.append(count_0 + " tab in the Morning, ");
        if (count_1 > 0)
            stringBuffer.append(count_1 + " tab in the Afternoon, ");
        if (count_2 > 0)
            stringBuffer.append(count_2 + " tab in the Evening.\t");
        return stringBuffer.toString();
    }

    public List<String> readTextFile() {
        String line = "";
        List<String> linesList = new ArrayList<>();

        try(InputStream is = this.getResources().openRawResource(R.raw.subscription_list);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));) {
            while((line = reader.readLine()) != null)
                linesList.add(line);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return linesList;
    }
}
