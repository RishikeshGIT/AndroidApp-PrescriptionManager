package com.example.prescriptionmanager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class SubmitAlarmConfirmationActivity extends AppCompatActivity {

    EditText set_morning_time, set_noon_time, set_evening_time;
    Button confirm_timings_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_alarm_confirmation);

        set_morning_time = (EditText) findViewById(R.id.MorningTime);
        set_noon_time = (EditText) findViewById(R.id.noonTime);
        set_evening_time = (EditText) findViewById(R.id.eveningTime);
        confirm_timings_btn = (Button) findViewById(R.id.confirmAlarmBtn);

        confirm_timings_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                Intent notificationIntent = new Intent(SubmitAlarmConfirmationActivity.this, AlarmReceiver.class);
                PendingIntent broadcast = PendingIntent.getBroadcast(getApplicationContext(), 100, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                Calendar calendar = Calendar.getInstance();

                    //Use this section only for testing the Notifications
                /*
                    calendar.add(Calendar.SECOND, 5);
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);
                 */

                //Calendar.HOUR_OF_DAY: is used for 24 hrs. format, and Calendar.HOUR is used for 12 hr. format

                int hrs = 0;
                int mins = 0;

                String enteredTime = null;
                Calendar cal_m = Calendar.getInstance();
                enteredTime = set_morning_time.getText().toString().trim();
                hrs = 9;
                if(enteredTime.indexOf(":") != -1) {
                    hrs = Integer.parseInt(enteredTime.split(":")[0]) % 12;
                    mins = Integer.parseInt(enteredTime.split(":")[1]);
                }
                cal_m.add(Calendar.HOUR, hrs);
                cal_m .add(Calendar.MINUTE, mins);
                cal_m.add(Calendar.SECOND, 0);

                Calendar cal_n = Calendar.getInstance();
                enteredTime = set_noon_time.getText().toString().trim();
                hrs = 13;
                mins = 30;
                if(enteredTime.indexOf(":") != -1) {
                    hrs = Integer.parseInt(enteredTime.split(":")[0]) % 12;
                    mins = Integer.parseInt(enteredTime.split(":")[1]);
                }
                cal_n.add(Calendar.HOUR, hrs);
                cal_n .add(Calendar.MINUTE, mins);
                cal_n.add(Calendar.SECOND, 0);

                Calendar cal_e = Calendar.getInstance();
                enteredTime = set_evening_time.getText().toString().trim();
                hrs = 19;
                mins = 30;
                enteredTime = set_noon_time.getText().toString().trim();
                if(enteredTime.indexOf(":") != -1) {
                    hrs = Integer.parseInt(enteredTime.split(":")[0]) % 12;
                    mins = Integer.parseInt(enteredTime.split(":")[1]);
                }
                cal_e.add(Calendar.HOUR, hrs);
                cal_e.add(Calendar.MINUTE, mins);
                cal_e.add(Calendar.SECOND, 0);

                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal_m.getTimeInMillis(), 24 * 60 * 60 * 1000 , broadcast);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal_m.getTimeInMillis(), broadcast);

                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal_n.getTimeInMillis(), 24 * 60 * 60 * 1000 , broadcast);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal_n.getTimeInMillis(), broadcast);

                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal_e.getTimeInMillis(), 24 * 60 * 60 * 1000 , broadcast);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal_e.getTimeInMillis(), broadcast);

                Toast.makeText(SubmitAlarmConfirmationActivity.this, "Alarm Settings have been saved. You'll receive the alarms at specified times.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
