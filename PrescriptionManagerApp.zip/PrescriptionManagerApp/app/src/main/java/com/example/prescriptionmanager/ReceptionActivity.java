package com.example.prescriptionmanager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ReceptionActivity extends AppCompatActivity {

    public static final String TAG = "TAG";
    EditText patientName, patientAddress, patientEmail, patientPhone;
    Button patientRegister;
    FirebaseFirestore firebaseFirestore;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reception);
        patientName = (EditText) findViewById(R.id.PatientName);
        patientAddress = (EditText) findViewById(R.id.PatientAddress);
        patientEmail = (EditText) findViewById(R.id.PatientEmail);
        patientPhone = (EditText) findViewById(R.id.PatientPhone);
        patientRegister = (Button) findViewById(R.id.PatientRegister);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        progressBar.setVisibility(View.INVISIBLE);
        patientRegister.setOnClickListener((v) -> {
            progressBar.setVisibility(View.VISIBLE); // Display Progress bar
            storePatientDataInDB(v, patientName.getText().toString().trim(), patientAddress.getText().toString().trim(),
                    patientEmail.getText().toString().trim(), patientPhone.getText().toString().trim());
            progressBar.setVisibility(View.GONE); // Hide Progress bar
        });
    }

    private void storePatientDataInDB(View view, String patientName, String address, String email, String phone) {
        firebaseFirestore = FirebaseFirestore.getInstance();
        String patientId = generatePatientId(email, phone);
        Map<String, String> patient = new HashMap<>();
        patient.put("name", patientName);
        patient.put("address", address);
        patient.put("email", email);
        patient.put("phone", phone);
        firebaseFirestore.collection("patients")
                .document(patientId)
                .set(patient)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Prescription data added for the Patient: " + patientName);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Could not save Patient's data: " + patientName);
                    }
                });
        Toast.makeText(ReceptionActivity.this, "Patient registration done successfully. Patient Id is:"+patientId, Toast.LENGTH_SHORT).show();
    }

    private String generatePatientId(String email, String phone) {
        return new StringBuffer(email.split("@")[0]).append(phone).toString();
    }
}
