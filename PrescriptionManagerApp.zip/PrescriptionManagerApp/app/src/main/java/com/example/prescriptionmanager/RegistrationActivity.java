package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {

    public static final String TAG = "TAG";
    EditText register_name, register_phone, register_email, register_password, register_password2;
    ProgressBar register_progressBar;
    Button register_button;
    FirebaseAuth firebaseAuth = null;
    FirebaseFirestore firebaseFirestore = null;
    TextView register_login_now_button;
    String doctorId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        register_name = (EditText) findViewById(R.id.RegisterName);
        register_phone = (EditText) findViewById(R.id.RegisterPhone);
        register_email = (EditText) findViewById(R.id.RegisterEmail);
        register_password = (EditText) findViewById(R.id.RegisterPassword);
        register_password2 = (EditText) findViewById(R.id.RegisterPassword2);
        register_progressBar = (ProgressBar) findViewById(R.id.progressBar);
        register_button = (Button) findViewById(R.id.RegisterBtn);
        register_login_now_button = (TextView) findViewById(R.id.alreadyRegisterBtn);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        if(firebaseAuth.getCurrentUser() != null) {
            Intent backToMainActivityForLogout = new Intent(getApplicationContext(), LoginActivity.class);
            backToMainActivityForLogout.putExtra("DOCTOR_LOGIN_STATE", "loggedIn");
            RegistrationActivity.this.startActivity(backToMainActivityForLogout);
            finish();
        }

        FirebaseAuth finalFirebaseAuth = firebaseAuth;
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = register_name.getText().toString().trim();
                String phone = register_phone.getText().toString().trim();
                String email = register_email.getText().toString().trim();
                String password_1 = register_password.getText().toString().trim();
                String password_2 = register_password2.getText().toString().trim();

                if (TextUtils.isEmpty(name)) {
                    register_name.setError("Name should not be blank");
                    return;
                }
                if (TextUtils.isEmpty(phone)) {
                    register_phone.setError("Phone Number should not be blank");
                    return;
                }
                if (!TextUtils.isDigitsOnly(phone)){
                    register_phone.setError("Phone Number should be digits only");
                    return;
                }
                if (TextUtils.isEmpty(email)){
                    register_email.setError("Email should not be blank");
                    return;
                }
                if (TextUtils.isEmpty(password_1)){
                    register_password.setError("Password should not be blank");
                    return;
                }
                if (TextUtils.isEmpty(password_2)){
                    register_password2.setError("Password should not be blank");
                    return;
                }
                if (!password_1.equals(password_2)){
                    register_password.setError("Both Passwords must be the same");
                    return;
                }
                if (password_1.length() < 6) {
                    register_password.setError("Password must be at least 6 characters long");
                    return;
                }
                register_progressBar.setVisibility(View.VISIBLE);
                //Register the user in FireBase
                finalFirebaseAuth.createUserWithEmailAndPassword(email, password_1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(RegistrationActivity.this, "Doctor is Registered successfully", Toast.LENGTH_SHORT).show();

                            doctorId = finalFirebaseAuth.getCurrentUser().getUid();
                            Map<String, Object> doctor = new HashMap<>();
                            doctor.put("doctorName", name);
                            doctor.put("doctorPhone", phone);
                            doctor.put("doctorEmail", email);
                            firebaseFirestore.collection("doctors")
                                    .document(doctorId)
                                    .set(doctor)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "Doctor Profile is added with Id: " + doctorId);
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error adding document doctor: ", e);
                                        }
                                    });
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        } else{
                            Toast.makeText(RegistrationActivity.this, "Doctor registration Failed."+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            register_progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });

        //If already registered go to the Login Page
        register_login_now_button.setOnClickListener((v) -> {
            Intent returnToLoginIntent = new Intent(RegistrationActivity.this, LoginActivity.class);
            RegistrationActivity.this.startActivity(returnToLoginIntent);
        });
    }
}
