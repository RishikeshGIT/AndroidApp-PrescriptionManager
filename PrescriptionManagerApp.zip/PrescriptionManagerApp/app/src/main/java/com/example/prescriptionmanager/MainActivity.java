package com.example.prescriptionmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btnDoctor = (Button) findViewById(R.id.Doctor);
        btnDoctor.setOnClickListener((v) -> {
            Intent loginIntent = new Intent(MainActivity.this, LoginActivity.class);
            MainActivity.this.startActivity(loginIntent);
        });

        final Button patientRegistrationBtn = (Button) findViewById(R.id.Reception);
        patientRegistrationBtn.setOnClickListener((v) -> {
            Intent patientRegistrationIntent = new Intent(MainActivity.this, ReceptionActivity.class);
            MainActivity.this.startActivity(patientRegistrationIntent);
        });

        final Button patientPageBtn = (Button) findViewById(R.id.Patient);
        patientPageBtn.setOnClickListener((v) -> {
            Intent patientPageIntent = new Intent(MainActivity.this, PatientLoginActivity.class);
            MainActivity.this.startActivity(patientPageIntent);
        });
    }
}
